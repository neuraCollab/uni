from scapy.all import *
from scapy.layers.inet import IP, TCP, ICMP

def is_suspicious(packet):
    if len(packet) > 1000:
        return True

    if packet.haslayer(TCP) and packet[TCP].flags == 'S':
        return True

    if packet.haslayer(TCP) and packet[TCP].flags == 'A':
        return False

    return False

def block_packet(packet):
    ip = IP(dst=packet[IP].src, src=packet[IP].dst)
    icmp = ICMP(type=3, code=3)
    send(ip/icmp/packet[IP])

def process_packet(packet):
    if is_suspicious(packet):
        print(f"Suspicious packet detected: {packet.summary()}")
        block_packet(packet)


sniff(prn=process_packet, filter="ip")
